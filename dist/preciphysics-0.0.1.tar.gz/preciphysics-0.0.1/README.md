### preciphysics

- Preciphysics is a Python library offering a bunch of meteological and numerical calculations.
- Apart from numerical calculations it offers some visualization plots such as meteogram, skew-T etc.
- This Python package is under development with an attempt to be taken onto further supportment.

> Experimental work by an Undergraduate Student dedicated to the improvement of the meteorological implications and numerical modelling studies in Turkey.

![](preciphysics/logo.png)

***by Berkay & Kutay DÖNMEZ***
